/*
*	Grupo 12
* @author Daniel Santos 44887
* @author Luis Barros  47082
* @author Marcus Dias 44901
*/

./table-client 127.0.0.1:44901 127.0.0.1:44902


-- Por decisao de na etapa anterior colocarmos a tentativa de voltar a enviar a mensagem no network_with_retry no client_stub, quando o cliente nota que o primario esta em baixo, essa parte do codigo foi colocado no network_with_retry
 
